import { useCallback, useEffect, useState } from "react"
import { HangmanDrawing } from "./HangmanDrawing"
import { HangmanWord } from "./HangmanWord"
import { Keyboard } from "./Keyboard"
import words from "./wordList.json"

function getWord() {
  return words[Math.floor(Math.random() * words.length)]
}

function App() {
  const [wordToGuess, setWordToGuess] = useState(getWord)
  const [guessedLetters, setGuessedLetters] = useState<string[]>([])
  

  const incorrectLetters = guessedLetters.filter(
    letter => !wordToGuess.includes(letter)
  )

  const isLoser = incorrectLetters.length >= 6
  const isWinner = wordToGuess
    .split("")
    .every(letter => guessedLetters.includes(letter))

  const addGuessedLetter = useCallback(
    (letter: string) => {
      if (guessedLetters.includes(letter) || isLoser || isWinner) return

      setGuessedLetters(currentLetters => [...currentLetters, letter])
    },
    [guessedLetters, isWinner, isLoser]
  )
  console.log( 'слово:', wordToGuess)
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const key = e.key
      if (!key.match(/^[a-z]$/)) return

      e.preventDefault()
      addGuessedLetter(key)
    }
  
    document.addEventListener("keypress", handler)

    return () => {
      document.removeEventListener("keypress", handler)
    }
  }, [guessedLetters])

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const key = e.key
      if (key !== "Enter") return

      e.preventDefault()
      setGuessedLetters([])
      setWordToGuess(getWord())
    }

    document.addEventListener("keypress", handler)

    return () => {
      document.removeEventListener("keypress", handler)
    }
    
  }, [])

  function refresh() {
    window.location.reload(false)
    
  }
  
  return (
    <div
      style={{
        maxWidth: "800px",
        display: "flex",
        flexDirection: "column",
        gap: "2rem",
        margin: "0 auto",
        alignItems: "center",
      }}
    >
      {/* <div style={{ fontSize: "2rem", textAlign: "center" }}>
        {isWinner && "Winner! - Refresh to try again"}
        {isLoser && "Nice Try - Refresh to try again"}
      </div> */}

      {isWinner ? 
      
      <div style={{
        width: '500px', 
        height: '500px', 
        position: 'absolute', 
        margin: '0 auto', 
        border: '2px solid black', 
        background: 'white', 
        zIndex: '10', 
        top: '20%', 
        borderRadius: '15px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '4rem',
        textAlign: 'center'
        }}>
          <span style={{fontSize: '40px', fontWeight: 'bold', color: 'limegreen'}}>You Win! <br /> 
           <span style={{fontSize: '30px', fontWeight: 'normal'}}> Want To Try Again</span>
          </span>    
          <span style={{fontSize: '25px'}}>The word was:  
            <span style={{color: 'limegreen'}}> {wordToGuess}</span>
          </span>     
          <button onClick={refresh} style={{width: '300px', height: '70px', background: 'hsl(900, 100%, 50%)', fontSize: '20px', fontWeight: 'bold', border: 'none', cursor: 'pointer'}}>Try Again</button>
        </div>
        : isLoser ? <div style={{
        width: '400px', 
        height: '400px', 
        position: 'absolute', 
        margin: '0 auto', 
        border: '2px solid black', 
        background: 'white', 
        zIndex: '10', 
        top: '20%', 
        borderRadius: '15px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '4rem',
        textAlign: 'center'

        }}>
          <span style={{fontSize: '40px', fontWeight: 'bold', color: 'red'}}>You Lose! <br /> 
           <span style={{fontSize: '30px', fontWeight: 'normal'}}> Come On Have Another Chanse </span>
          </span>
          <span style={{fontSize: '25px'}}>The word was:  
            <span style={{color: 'red'}}> {wordToGuess}</span>
          </span>
          <button onClick={refresh} style={{width: '300px', height: '70px', background: 'hsl(900, 100%, 50%)', fontSize: '20px', fontWeight: 'bold', border: 'none', cursor: 'pointer'}}>Try Again</button>
        </div>
        : ''
      }
      
  
      <HangmanDrawing numberOfGuesses={incorrectLetters.length} />
      <HangmanWord
        reveal={isLoser}
        guessedLetters={guessedLetters}
        wordToGuess={wordToGuess}
      />
      <div style={{ alignSelf: "stretch" }}>
        <Keyboard
          disabled={isWinner || isLoser}
          activeLetters={guessedLetters.filter(letter =>
            wordToGuess.includes(letter)
          )}
          inactiveLetters={incorrectLetters}
          addGuessedLetter={addGuessedLetter}
        />
      </div>
    </div>
  )
}

export default App
